package T5;

public class ConstructorDeclarationTest1 {

	public ConstructorDeclarationTest1() {}
	
}
