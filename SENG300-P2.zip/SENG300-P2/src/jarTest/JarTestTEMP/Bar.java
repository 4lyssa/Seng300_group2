package Foo;

public class Bar {

	Bar b = new Bar(); 

}