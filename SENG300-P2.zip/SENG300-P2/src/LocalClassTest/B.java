public class B {
        
        public void z{
            
            class C {}
        }
}