package T4;

import java.util.Map; 

public class ParameterizedTypeTest1234 {

	Map<String, int[]> map;
}
